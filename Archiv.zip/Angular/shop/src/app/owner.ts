export class Owner{
  id:number;
  name: string;
}
