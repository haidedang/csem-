import { Component, OnInit, Input } from '@angular/core';
import {Owner} from "../owner";
import {HttpClient} from "@angular/common/http";

@Component({
  selector: 'app-owner-detail',
  templateUrl: './owner-detail.component.html',
  styleUrls: ['./owner-detail.component.css']
})
export class OwnerDetailComponent implements OnInit {
  @Input() owner:Owner;

  constructor(private http:HttpClient) { }

  ngOnInit() {
  }

  saveChanges(){
      this.http.put('http://localhost:5000/owner/'+ this.owner.id, this.owner).subscribe(data => console.log(data));
  }
}
