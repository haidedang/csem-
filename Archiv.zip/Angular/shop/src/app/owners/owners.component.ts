import { Component, OnInit } from '@angular/core';
import {Owner} from "../owner";
import {HttpClient} from "@angular/common/http";

@Component({
  selector: 'app-owners',
  templateUrl: './owners.component.html',
  styleUrls: ['./owners.component.css']
})
export class OwnersComponent implements OnInit {
  owners:Owner[] = [];
  selectedOwner:Owner;

  constructor(private http:HttpClient) { }

  ngOnInit() {
    this.http.get('http://localhost:5000/owner').subscribe(info =>{
      this.owners = info["data"];
    })
  }

  onSelect(owner:Owner):void {
    this.selectedOwner = owner;
}

}
