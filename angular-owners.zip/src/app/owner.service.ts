import { Injectable } from '@angular/core';
import { Owner } from './owner';
import { OWNERS } from './mock-owners';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { MessageService } from './message.service'
import { HttpClient, HttpHeaders } from '@angular/common/http'

@Injectable()
export class OwnerService {

  constructor(private messageService: MessageService) { }

  getOwners(): Observable<Owner[]>{
    this.messageService.add('OwnerService: fetched owners')
    return of (OWNERS);
  }
  getOwner(id: number): Observable<Owner> {
    // Todo: send the message _after_ fetching the hero
    this.messageService.add(`OwnerService: fetched owner id=${id}`);
    return of(OWNERS.find(owner => owner.id === id));
  }
}
