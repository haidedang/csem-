import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { OwnersComponent } from './owners/owners.component';
import { DashboardComponent }   from './dashboard/dashboard.component';
import { OwnerDetailComponent } from './owner-detail/owner-detail.component'

const routes: Routes = [
  { path: 'owners', component: OwnersComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'detail/:id', component: OwnerDetailComponent },
]

@NgModule({
  exports: [ RouterModule ],
  imports: [RouterModule.forRoot(routes)]
})
export class AppRoutingModule {}